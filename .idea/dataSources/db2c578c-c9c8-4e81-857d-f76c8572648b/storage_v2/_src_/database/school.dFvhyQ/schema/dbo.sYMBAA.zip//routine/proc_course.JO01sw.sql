create procedure proc_course
as
select student.stu_id,stu_name,grade
from student join studentgrade on student.stu_id=studentgrade.stu_id
where course_id='0108'
go

