create proc proc_year
   @year int=20
as
select *
from student
where @year=year(getdate())-year(birthday)
go

