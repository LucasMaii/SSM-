create proc proc_year1
   @year int=20,
   @count int output
as
begin
	select @count=count(*)
	from student
	where @year>year(getdate())-year(birthday) 
end
go

