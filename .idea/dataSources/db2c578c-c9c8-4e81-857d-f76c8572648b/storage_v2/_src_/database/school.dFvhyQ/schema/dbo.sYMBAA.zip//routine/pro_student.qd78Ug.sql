    CREATE PROCEDURE pro_student
       AS 
       SELECT Stu_id,Stu_name
       FROM student
    go

