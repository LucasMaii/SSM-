create proc RandNum
(@l int=1,@h int=99,@r int output)
as
if @h<=@l return(-1)
while @h>@l 
 begin
  set @r=floor(RAND()*@h)
  if @r>=@l and @r<@h return(1)
 end
go

