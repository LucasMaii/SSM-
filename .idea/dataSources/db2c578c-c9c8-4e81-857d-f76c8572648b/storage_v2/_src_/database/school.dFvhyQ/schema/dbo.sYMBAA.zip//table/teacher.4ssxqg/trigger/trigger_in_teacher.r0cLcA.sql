CREATE TRIGGER trigger_in_teacher
ON teacher
FOR INSERT
AS 
BEGIN
  UPDATE deparment
  SET teac_num=teac_num+(SELECT COUNT(*) FROM INSERTED
                WHERE deparment.depar_id=INSERTED.depar_id)
END
go

