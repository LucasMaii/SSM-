  Create proc AvgGrade
    (@sid varchar(9),@sname varchar(8) output,@sex varchar(2) output)    
      as
    select @sname=stu_name,@sex=stu_sex
    from Student    
    where Stu_id=@sid
  go

