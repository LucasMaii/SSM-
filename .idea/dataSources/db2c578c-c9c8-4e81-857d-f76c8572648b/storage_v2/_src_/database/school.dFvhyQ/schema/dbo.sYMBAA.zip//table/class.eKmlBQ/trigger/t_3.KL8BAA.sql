create trigger T_3 on dbo.Class
instead of update
as 
BEGIN
   UPDATE student
   SET class_id=(SELECT class_id FROM inserted)
   WHERE class_id IN (SELECT class_id FROM deleted)
   UPDATE courseteacher
   SET class_id=(SELECT class_id FROM inserted)
   WHERE class_id IN (SELECT class_id FROM deleted)
END
go

