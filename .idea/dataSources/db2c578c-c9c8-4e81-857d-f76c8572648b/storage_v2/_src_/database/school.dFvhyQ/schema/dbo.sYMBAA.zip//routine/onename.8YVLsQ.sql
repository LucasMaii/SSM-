
CREATE  proc OneName
(@name varchar(8) output)
as
declare @a int
set @a=floor(RAND()*1000)
select @Name=substring(fir,@a%200,1)+substring(sec,@a%400,1)+substring(thi,@a%400,1) from test_TheName


go

