create proc proc_jiecheng
 @n int    --此处声明的为输入输出参数
as
declare @i int    --此处声明的为存储过程内部使用的变量
declare @sum bigint
set @i=1
set @sum=1
while @i<=@n
 begin
    set @sum=@sum*@i
    set @i=@i+1
 end
print @sum
go

