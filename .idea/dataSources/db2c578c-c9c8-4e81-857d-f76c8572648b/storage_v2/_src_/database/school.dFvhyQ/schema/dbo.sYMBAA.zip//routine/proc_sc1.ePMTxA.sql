CREATE proc proc_sc1
 @sno varchar(9)='000001',   --注意：当变量有默认值时，不能用declare声明变量。
 @markpass int
as
select student.stu_id,stu_name,grade
from student join studentgrade on student.stu_id=studentgrade.stu_id
where student.stu_id=@sno and grade<@markpass
go

