CREATE PROCEDURE p_student_sno
     	@givensno char(10)
     AS 
     SELECT Stu_id,Stu_name
     FROM student
     WHERE Stu_id =@givensno;
go

