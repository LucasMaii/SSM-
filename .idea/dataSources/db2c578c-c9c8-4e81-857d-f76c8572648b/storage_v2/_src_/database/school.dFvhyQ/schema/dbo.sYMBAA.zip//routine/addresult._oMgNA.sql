CREATE proc addresult
    (@n int)
    as    
begin
    declare @i int,@sum int
    if @n<1 print('Error!')
else    
       begin
         set @sum=0
         set @i=1
         while @i<=@n
              begin
                set @sum=@sum+@i
                set @i=@i+1
              end  
         print @sum
       end 
end
go

